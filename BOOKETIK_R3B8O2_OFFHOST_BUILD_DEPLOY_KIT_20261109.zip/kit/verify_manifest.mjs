import fs from 'node:fs';
import path from 'node:path';
const root = process.argv[2];
const build = path.join(root, 'public/build');
const manifestPath = path.join(build, 'manifest.json');
if (!fs.existsSync(manifestPath)) throw new Error('VITE_MANIFEST_MISSING');
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const keys = ['resources/js/app.jsx',...['almanac','civic','marquee'].map(t=>`resources/js/Themes/${t}/Pages/Site/Event.jsx`)];
for (const key of keys) {
  const item = manifest[key];
  if (!item?.file || !item.file.startsWith('assets/') || !fs.existsSync(path.join(build,item.file))) throw new Error(`MISSING_MANIFEST_ENTRY ${key}`);
  if (item.imports) for (const imported of item.imports) {
    if (!manifest[imported]?.file || !fs.existsSync(path.join(build,manifest[imported].file))) throw new Error(`MISSING_IMPORT ${key} ${imported}`);
  }
}
const ssr = path.join(root,'bootstrap/ssr/ssr.js');
if (!fs.existsSync(ssr) || fs.statSync(ssr).size < 1000) throw new Error('SSR_EMPTY_OR_MISSING');
console.log('BUILD_MANIFEST=PASS THREE_THEMES=PASS SSR=PASS');
