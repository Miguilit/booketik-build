#!/usr/bin/env bash
set -euo pipefail
# Usage: bash rollback.sh /home/.../booketik.com STAGE_PATH ASSET_BACKUP_PATH CODE_BACKUP_PATH
ROOT="$(cd "${1:?root}" && pwd -P)"
STAGE="$(cd "${2:?release stage}" && pwd -P)"
BACKUP="$(cd "${3:?asset backup}" && pwd -P)"
CODE="$(cd "${4:?code backup}" && pwd -P)"
APP="$ROOT/eventgoo"
PKG="$STAGE/release/package"
[[ -d "$BACKUP/assets/build" && -f "$PKG/rollback.sh" ]] || { echo 'BACKUP_INCOMPLETE'; exit 2; }
( cd "$APP" && sha256sum -c "$PKG/package_hashes.txt" >/dev/null ) || { echo 'LIVE_CODE_DRIFT=FAIL'; exit 2; }
( cd "$STAGE/release" && while read -r digest f; do live="$APP/${f#assets/}"; [[ -f "$live" && "$(sha256sum "$live" | cut -d' ' -f1)" == "$digest" ]] || { echo "LIVE_ASSET_DRIFT=FAIL $f"; exit 1; }; done < asset_hashes.txt )
rm -rf "$APP/public/build" "$APP/bootstrap/ssr"
cp -a "$BACKUP/assets/build" "$APP/public/build"
if [[ -d "$BACKUP/assets/ssr" ]]; then cp -a "$BACKUP/assets/ssr" "$APP/bootstrap/ssr"; fi
bash "$PKG/rollback.sh" "$APP" "$CODE"
"${BOOKETIK_PHP_BIN:-/opt/alt/php84/usr/bin/php}" "$APP/artisan" optimize:clear
echo 'ROLLBACK_FULL=PASS SSR_SERVICE_RESTART=MANUAL_IF_RUNNING'
