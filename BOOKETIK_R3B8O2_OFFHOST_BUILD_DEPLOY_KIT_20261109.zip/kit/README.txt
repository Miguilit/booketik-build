BOOKETIK R3-B8-O2 — BUILD EXTERNE ET DEPLOIEMENT PROTEGE

STATUT : kit de compilation, PAS un bundle React deja compile.

Entrees verifiees :
- Source collectee : BOOKETIK_R3B8O2_FRONTEND_BUILD_SOURCE_20261109T133219Z.tar.gz
  SHA256 181cbe78ccfa1668c0fb8efec4377ad0faf9980cb42bb9bc38fedb5ed361a92f
- Patch public : BOOKETIK_R3B8O2_PUBLIC_CLAIM_NATIVE_THEMES_GUARDED_20261109.zip
  SHA256 c21ed0134b2231904e78e60085b08ce10e2f65ec92042bb7f1498b30eba22daa (fourni dans inputs/)

Pourquoi ? Sur Hostinger, node/npm ne sont pas disponibles dans la session SSH et ici
la resolution npm ne fonctionne pas ; npm ci ne peut donc pas etre execute.

PHASE A — Linux/CI AVEC NODE.JS 22.12+ ET ACCES INTERNET AU REGISTRE NPM :
1. Extraire ce kit (ZIP) et placer l'archive SOURCE (TAR.GZ) a cote.
2. bash build.sh /chemin/vers/BOOKETIK_R3B8O2_FRONTEND_BUILD_SOURCE_20261109T133219Z.tar.gz /dossier/de/sortie
3. Ce script controle les SHA et les 3 variantes de React, execute npm ci via le
   package-lock, puis npm run build (client et SSR). Il cree :
   BOOKETIK_R3B8O2_COMPILED_FOR_HOSTINGER_20261109.tar.gz
   BOOKETIK_R3B8O2_COMPILED_FOR_HOSTINGER_20261109.tar.gz.sha256
4. Ce sera le bundle *compile* ; il n'est PAS present dans ce kit.

PHASE B — HOSTINGER :
1. Deposer les deux fichiers generes sous ~/domains/booketik.com/
2. Deposer ce kit et le decompresser dans un sous-dossier prive sur Hostinger.
3. bash /chemin/du/kit/deploy.sh ~/domains/booketik.com
4. En cas de besoin, suivre les chemins BACKUP_PATH, CODE_BACKUP_PATH et RELEASE_STAGE
   affiches par le deploiement, puis utiliser :
   bash /chemin/du/kit/rollback.sh ~/domains/booketik.com RELEASE_STAGE BACKUP_PATH CODE_BACKUP_PATH

GUARDS : verifie le SHA de l'archive, du patch, des sources, le manifest Vite,
le SHA du manifest deja en production, et tous les assets deployes.
Le rollback ne supprime pas de tables et ne modifie aucune donnee SQL.
Le processus SSR actif, s'il existe, doit etre redemarre de maniere controlee.

NE PAS executer deploy.sh avant la production du bundle compile.
