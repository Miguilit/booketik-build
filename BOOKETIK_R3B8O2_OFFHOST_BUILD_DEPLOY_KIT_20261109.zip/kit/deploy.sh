#!/usr/bin/env bash
set -euo pipefail
# Run on Hostinger after uploading BOTH the compiled .tar.gz and its .sha256.
ROOT="${1:-$HOME/domains/booketik.com}"
ROOT="$(cd "$ROOT" && pwd -P)"
APP="$ROOT/eventgoo"
FILE="$ROOT/BOOKETIK_R3B8O2_COMPILED_FOR_HOSTINGER_20261109.tar.gz"
SUM="$FILE.sha256"
[[ -f "$APP/artisan" && -f "$APP/routes/web.php" && -f "$FILE" && -f "$SUM" ]] || { echo 'APP_OR_RELEASE_MISSING'; exit 2; }
( cd "$ROOT" && sha256sum -c "$(basename "$SUM")" ) || { echo 'RELEASE_SHA=FAIL'; exit 2; }
if tar -tzf "$FILE" | grep -Eq '(^/|(^|/)\.\.(/|$))'; then echo 'RELEASE_UNSAFE_PATH'; exit 2; fi
STAGE="$(mktemp -d "$ROOT/_private_r3b8o2_release_XXXXXX")"
# Preserve extracted package for rollback; this directory is NOT removed.
tar -xzf "$FILE" -C "$STAGE"
REL="$STAGE/release"
PKG="$REL/package"
ASSET="$REL/assets"
[[ -f "$PKG/preflight.sh" && -f "$ASSET/public/build/manifest.json" && -f "$ASSET/bootstrap/ssr/ssr.js" ]] || { echo 'RELEASE_INCOMPLETE'; exit 2; }
( cd "$REL" && sha256sum -c asset_hashes.txt >/dev/null ) || { echo 'ASSET_SHA=FAIL'; exit 2; }
PHP="${BOOKETIK_PHP_BIN:-/opt/alt/php84/usr/bin/php}"
[[ -x "$PHP" ]] || { echo 'PHP84_MISSING'; exit 2; }
"$PHP" -r '
$m=json_decode(file_get_contents($argv[1]),true,512,JSON_THROW_ON_ERROR);
foreach(["resources/js/app.jsx","resources/js/Themes/almanac/Pages/Site/Event.jsx","resources/js/Themes/civic/Pages/Site/Event.jsx","resources/js/Themes/marquee/Pages/Site/Event.jsx"] as $k){
 $f=$m[$k]["file"]??null;
 if(!is_string($f) || !str_starts_with($f,"assets/") || !is_file(dirname($argv[1])."/".$f)){fwrite(STDERR,"MANIFEST_ENTRY_MISSING: $k\n");exit(1);}
}
echo "COMPILED_MANIFEST=PASS\n";
' "$ASSET/public/build/manifest.json"
# Old build manifest must be the one collected, preventing overwrite after unexpected frontend deployment.
OLD_MANIFEST_SHA='2359768e19eee9397c20a700db60d0141a017ac6706523abc6caf685f0c07ba9'
[[ "$(sha256sum "$APP/public/build/manifest.json" | cut -d' ' -f1)" == "$OLD_MANIFEST_SHA" ]] || { echo 'LIVE_MANIFEST_DRIFT=FAIL'; exit 2; }
echo '===== PREFLIGHT ====='
bash "$PKG/preflight.sh" "$APP"
BACKUP="$(mktemp -d "$ROOT/booketik_r3b8o2_full_backup_$(date -u +%Y%m%dT%H%M%SZ)_XXXX")"
mkdir -p "$BACKUP/assets"
cp -a "$APP/public/build" "$BACKUP/assets/build"
if [[ -d "$APP/bootstrap/ssr" ]]; then cp -a "$APP/bootstrap/ssr" "$BACKUP/assets/ssr"; fi
[[ -d "$BACKUP/assets/build" ]] || { echo 'ASSET_BACKUP=FAIL'; exit 2; }
# Stage assets before installing code, to minimize the time of the swap.
NEXT_BUILD="$(mktemp -d "$APP/public/.booketik_r3b8o2_next_build_XXXXXX")"
cp -a "$ASSET/public/build/." "$NEXT_BUILD/"
NEXT_SSR="$(mktemp -d "$APP/bootstrap/.booketik_r3b8o2_next_ssr_XXXXXX")"
cp -a "$ASSET/bootstrap/ssr/." "$NEXT_SSR/"
CODE_BACKUP=''
CODE_INSTALLED=0
ASSETS_TOUCHED=0
recover() {
  rc=$?
  if (( rc != 0 )); then
    echo "DEPLOY_FAILED=$rc ATTEMPTING_ROLLBACK=YES"
    if (( ASSETS_TOUCHED == 1 )); then
      rm -rf "$APP/public/build" "$APP/bootstrap/ssr"
      cp -a "$BACKUP/assets/build" "$APP/public/build" || echo 'MANUAL_PUBLIC_ASSET_ROLLBACK_REQUIRED'
      if [[ -d "$BACKUP/assets/ssr" ]]; then cp -a "$BACKUP/assets/ssr" "$APP/bootstrap/ssr"; fi
    fi
    if (( CODE_INSTALLED == 1 )) && [[ -n "$CODE_BACKUP" ]]; then
      bash "$PKG/rollback.sh" "$APP" "$CODE_BACKUP" || echo 'MANUAL_CODE_ROLLBACK_REQUIRED'
    fi
  fi
}
trap recover EXIT
printf '===== SOURCE INSTALLATION =====\n'
CODE_OUTPUT="$(bash "$PKG/install.sh" "$APP" --apply)" || { printf '%s\n' "$CODE_OUTPUT"; exit 1; }
printf '%s\n' "$CODE_OUTPUT"
CODE_BACKUP="$(printf '%s\n' "$CODE_OUTPUT" | sed -n 's/^BACKUP_PATH=//p' | tail -1)"
[[ -d "$CODE_BACKUP" ]] || { echo 'CODE_BACKUP_MISSING'; exit 1; }
CODE_INSTALLED=1
printf '===== ASSET DEPLOYMENT =====\n'
ASSETS_TOUCHED=1
rm -rf "$APP/public/build"
mv "$NEXT_BUILD" "$APP/public/build"
rm -rf "$APP/bootstrap/ssr"
mv "$NEXT_SSR" "$APP/bootstrap/ssr"
( cd "$APP" && sha256sum -c "$PKG/package_hashes.txt" >/dev/null )
# Verify exact deployed assets, not merely the manifest file.
( cd "$REL" && while read -r digest f; do live="$APP/${f#assets/}"; [[ -f "$live" && "$(sha256sum "$live" | cut -d' ' -f1)" == "$digest" ]] || { echo "LIVE_ASSET_SHA=FAIL $f"; exit 1; }; done < asset_hashes.txt )
bash "$PKG/verify.sh" "$APP"
"$PHP" "$APP/artisan" optimize:clear
trap - EXIT
echo 'DEPLOYMENT=PASS PHP=PASS CLIENT=PASS SSR_FILES=PASS'
echo "BACKUP_PATH=$BACKUP"
echo "CODE_BACKUP_PATH=$CODE_BACKUP"
echo "RELEASE_STAGE=$STAGE"
echo 'SSR_SERVICE_RESTART=MANUAL_IF_RUNNING'
echo 'NO_DATABASE_WRITES_BY_DEPLOYER=YES NO_PRICING_OR_TICKETING_CHANGES=YES'
