#!/usr/bin/env bash
set -euo pipefail
# Run on a Linux machine/CI with Node.js >= 22.12, npm, tar, unzip, sha256sum.
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
INPUT="${1:?Usage: bash build.sh /path/to/BOOKETIK_R3B8O2_FRONTEND_BUILD_SOURCE_20261109T133219Z.tar.gz [output_directory]}"
OUT="${2:-$PWD}"
INPUT="$(cd "$(dirname "$INPUT")" && pwd -P)/$(basename "$INPUT")"
mkdir -p "$OUT"
OUT="$(cd "$OUT" && pwd -P)"
SOURCE_SHA='181cbe78ccfa1668c0fb8efec4377ad0faf9980cb42bb9bc38fedb5ed361a92f'
PATCH_SHA='c21ed0134b2231904e78e60085b08ce10e2f65ec92042bb7f1498b30eba22daa'
PATCH="$KIT/inputs/BOOKETIK_R3B8O2_PUBLIC_CLAIM_NATIVE_THEMES_GUARDED_20261109.zip"
[[ -f "$INPUT" && -f "$PATCH" ]] || { echo 'INPUT_MISSING'; exit 1; }
[[ "$(sha256sum "$INPUT" | cut -d' ' -f1)" == "$SOURCE_SHA" ]] || { echo 'SOURCE_ARCHIVE_SHA=FAIL'; exit 1; }
[[ "$(sha256sum "$PATCH" | cut -d' ' -f1)" == "$PATCH_SHA" ]] || { echo 'PATCH_ARCHIVE_SHA=FAIL'; exit 1; }
command -v node >/dev/null && command -v npm >/dev/null && command -v unzip >/dev/null && command -v tar >/dev/null || { echo 'NODE_NPM_UNZIP_TAR_REQUIRED'; exit 2; }
node -e 'const v=process.versions.node.split(".").map(Number); if(v[0]<22||(v[0]===22&&v[1]<12))process.exit(1)' || { echo 'NODE_22_12_OR_NEWER_REQUIRED'; exit 2; }
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
# Tar and ZIP archives are known by SHA; still reject traversal paths.
if tar -tzf "$INPUT" | grep -Eq '(^/|(^|/)\.\.(/|$))'; then echo 'UNSAFE_SOURCE_ARCHIVE'; exit 2; fi
mkdir -p "$WORK/patch"
tar -xzf "$INPUT" -C "$WORK"
unzip -q "$PATCH" -d "$WORK/patch"
SRC="$WORK/source"
PKG="$WORK/patch/package"
( cd "$SRC" && sha256sum -c "$WORK/source_sha256.txt" >/dev/null ) || { echo 'COLLECTED_SOURCE_SHA=FAIL'; exit 2; }
( cd "$PKG/files" && sha256sum -c "$PKG/package_hashes.txt" >/dev/null ) || { echo 'PATCH_SHA=FAIL'; exit 2; }
for THEME in almanac civic marquee; do
  FILE="resources/js/Themes/$THEME/Pages/Site/Event.jsx"
  EXPECTED="$(awk -v f="$FILE" '$2==f {print $1}' "$PKG/source_hashes.txt")"
  [[ -n "$EXPECTED" && "$(sha256sum "$SRC/$FILE" | cut -d' ' -f1)" == "$EXPECTED" ]] || { echo "THEME_BASELINE_SHA=FAIL $THEME"; exit 2; }
  cp "$PKG/files/$FILE" "$SRC/$FILE"
  test "$(sha256sum "$SRC/$FILE" | cut -d' ' -f1)" = "$(awk -v f="$FILE" '$2==f {print $1}' "$PKG/package_hashes.txt")" || { echo 'THEME_PATCH_SHA=FAIL'; exit 2; }
done
cd "$SRC"
echo '===== NODE / NPM ====='
node -v
npm -v
echo '===== INSTALLATION DEPENDENCIES FROM LOCKFILE ====='
npm ci --no-audit --no-fund
echo '===== BUILD VITE CLIENT + SSR ====='
npm run build
node "$KIT/verify_manifest.mjs" "$SRC"
test -f "$SRC/bootstrap/ssr/ssr.js" || { echo 'SSR_BUILD_MISSING'; exit 2; }
RELEASE="$WORK/release"
mkdir -p "$RELEASE/assets/public" "$RELEASE/assets/bootstrap"
cp -a "$PKG" "$RELEASE/package"
cp -a "$SRC/public/build" "$RELEASE/assets/public/build"
cp -a "$SRC/bootstrap/ssr" "$RELEASE/assets/bootstrap/ssr"
( cd "$RELEASE" && find assets -type f -print0 | sort -z | xargs -0 sha256sum > asset_hashes.txt )
( cd "$RELEASE" && sha256sum -c asset_hashes.txt >/dev/null )
cat > "$RELEASE/BUILD_INFO.txt" <<EOF
BOOKETIK_R3B8O2_RELEASE=COMPILED
SOURCE_ARCHIVE_SHA256=$SOURCE_SHA
PATCH_ARCHIVE_SHA256=$PATCH_SHA
NODE_VERSION=$(node -v)
NPM_VERSION=$(npm -v)
BUILD_TYPE=VITE_CLIENT_AND_SSR
EOF
NAME='BOOKETIK_R3B8O2_COMPILED_FOR_HOSTINGER_20261109.tar.gz'
( cd "$WORK" && tar -czf "$OUT/$NAME" release )
( cd "$OUT" && sha256sum "$NAME" > "$NAME.sha256" )
echo 'COMPILED_BUILD=PASS CLIENT=PASS SSR=PASS'
echo "UPLOAD_TO_HOSTINGER=$OUT/$NAME"
echo "UPLOAD_CHECKSUM_TO_HOSTINGER=$OUT/$NAME.sha256"
( cd "$OUT" && cat "$NAME.sha256" )
