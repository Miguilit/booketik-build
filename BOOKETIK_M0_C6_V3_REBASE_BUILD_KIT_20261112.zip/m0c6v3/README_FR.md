# BOOKETIK — M0-C6 V3 : Fusion tarifs externes + Studio / Plan de salle

**Nature :** kit de compilation GitHub Actions, PAS un package d'installation Hostinger.

## Sources verrouillées
- Snapshot LIVE frontend du 12 novembre 2026 (489 fichiers ; manifeste client 226 entrées ; SSR S6A3).
- Sources des développements parallèles : S4C, S5C, S5D, S6A, S6A2 et S6A3 R2.
- Patch M0-C6 V2 : 15 fichiers (prix, gratuité, disponibilité, 3 thèmes, FR/NL).
- Chaque archive est protégée par SHA256, ainsi que les 17 sources avant modification et les 24 modules reconstitués.

## Exécution
1. Placer le ZIP de ce kit à la racine du dépôt privé `booketik-build`, **sans l'extraire**.
2. Copier le workflow `BOOKETIK_M0_C6_V3_GITHUB_WORKFLOW_20261112.yml` dans `.github/workflows/booketik-m0c6-v3.yml`.
3. Dans GitHub Actions : **BOOKETIK M0-C6 V3 Merge Studio & External Prices** → **Run workflow**.
4. Récupérer l'artefact `booketik-m0c6-v3-merged-compiled` et le joindre dans cette conversation.

La compilation utilise Node.js 22 et Python 3.11 SUR LE RUNNER GITHUB uniquement. **Aucune commande Python n'est destinée à Hostinger.** Aucun `/dev/fd` n'est nécessaire, ni en build ni sur Hostinger.

## Contrôles
- 489 fichiers de l'instantané vérifiés ; correspondance des 17 fichiers M0-C6 au baseline.
- Les 24 sources Studio et Plan de salle sont reconstruites dans leur ordre de versions certifié.
- Les 15 modifications tarifaires sont appliquées uniquement après vérification des sources.
- Tests UI M0-C6 : 38 assertions, et protection du checkout externe.
- La règle `themes:check` comporte **2 violations préexistantes sur `VenueManager/Studio.jsx`** (icônes sparkle/wand). Le kit compare les violations AVANT/APRÈS pour bloquer toute régression M0-C6, mais ne prétend pas avoir résolu ces violations antérieures.
- Build Vite client + Inertia SSR, manifestes client et SSR, les 3 entrées Studio/Plan de salle et FR/NL/EN.
- Le livrable inclut les 24 sources ajoutées et les 15 sources modifiées pour un futur package d'installation avec gardes SHA, backup et rollback.

## Limites et sécurité
- Aucun changement de production n'est effectué par le workflow.
- M0-C6 V2 ne doit PAS être installé : il effacerait les nouveaux modules en remplaçant les assets avec un build ancien.
- Le build Vite complet n'a **pas** été certifié localement : `npm ci` n'a pas abouti dans l'environnement d'analyse. Le résultat GitHub reste nécessaire avant toute installation.
- Ne pas nettoyer `_private` ni ses plans de restauration M0-C4/M0-C5.
