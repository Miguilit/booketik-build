#!/usr/bin/env python3
"""GitHub-side guarded source assembler. Not for execution on Hostinger."""
from pathlib import Path, PurePosixPath
import hashlib, json, subprocess, shutil, sys, tarfile, zipfile, re

def fail(msg):
    raise SystemExit('M0_C6_V3_FAIL='+str(msg))
def sha(data):
    return hashlib.sha256(data).hexdigest()
def check_sha_file(path, root):
    count=0
    for line in path.read_text().splitlines():
        if not line.strip(): continue
        expected, rel=line.split(maxsplit=1)
        rel=rel.lstrip('*')
        target=(root/rel)
        if not target.is_file() or target.is_symlink() or sha(target.read_bytes())!=expected:
            fail('SHA_MISMATCH:'+rel)
        count+=1
    return count
def safe_path(path):
    p=PurePosixPath(path)
    return not (path.startswith('/') or '..' in p.parts or '\\' in path or not path or any(x in ('','.env','node_modules','.git','vendor') for x in p.parts))

def main():
    kit=Path(sys.argv[1]).resolve(); work=Path(sys.argv[2]).resolve()
    if work.exists():fail('OUTPUT_ALREADY_EXISTS')
    work.mkdir(parents=True)
    inp=kit/'inputs'
    count=check_sha_file(kit/'guards/inputs.sha256',kit)
    if count!=7:fail('INPUT_COUNT')
    names=json.loads((kit/'guards/input_map.json').read_text())
    tar=inp/names['live']
    with tarfile.open(tar,'r:gz') as ar:
        seen=set()
        for e in ar.getmembers():
            if not safe_path(e.name) or e.name in seen or not (e.isfile() or e.isdir()):fail('UNSAFE_SNAPSHOT:'+e.name)
            if not (e.name in ('source','meta','source/','meta/') or e.name.startswith(('source/','meta/'))):fail('UNEXPECTED_SNAPSHOT_ITEM:'+e.name)
            seen.add(e.name)
            dst=work/e.name
            if e.isdir(): dst.mkdir(parents=True,exist_ok=True)
            else:
                dst.parent.mkdir(parents=True,exist_ok=True)
                dst.write_bytes(ar.extractfile(e).read())
    src=work/'source';meta=work/'meta'
    assert (src/'package-lock.json').is_file() and (src/'resources/js/pages.jsx').is_file()
    baseline_count=check_sha_file(meta/'source_copied.sha256',src)
    if baseline_count!=489:fail('SNAPSHOT_COUNT:'+str(baseline_count))
    active=json.loads((kit/'guards/active_assets.json').read_text())
    if sha((meta/'live_manifest.json').read_bytes())!=active['manifest_sha256'] or (meta/'ssr_sha256.txt').read_text().strip()!=active['ssr_sha256']:
        fail('ACTIVE_ASSET_SHA_MISMATCH')
    manifest=json.loads((meta/'live_manifest.json').read_text())
    if len(manifest)!=active['manifest_entries']:fail('LIVE_MANIFEST_ENTRIES')
    for page in active['required_modules']:
        if not any(k.endswith('/'+page) for k in manifest):fail('LIVE_MANIFEST_MODULE_MISSING:'+page)
    expected_sources=check_sha_file(kit/'guards/current.sha256',src)
    if expected_sources!=17:fail('M0_C6_BASELINE_SOURCES')
    # strict layer reconstruction: no application source may be overwritten unless earlier certified layer owns it
    source_sha_before={}
    for label in ('s4c','s5c','s5d','s6a','s6a2','s6a3'):
        archive=inp/names[label]
        prefix=archive.name.removesuffix('.zip').removesuffix('_R2')
        entries=[]
        with zipfile.ZipFile(archive) as z:
            for info in z.infolist():
                if info.is_dir():continue
                if not safe_path(info.filename):fail('UNSAFE_LAYER:'+info.filename)
                for head in (prefix+'/dependencies/s3t3-react/', prefix+'/frontend/'):
                    if info.filename.startswith(head):
                        rel=info.filename[len(head):]
                        if rel.startswith('resources/js/'):
                            entries.append((rel,z.read(info.filename)))
            if not entries:fail('EMPTY_LAYER:'+label)
        for rel,content in entries:
            target=src/rel
            if target.is_file():
                old=target.read_bytes()
                if rel not in source_sha_before:
                    if old!=content:fail('SOURCE_ALREADY_CONFLICT:'+rel)
                else:
                    if sha(old)!=source_sha_before[rel]:fail('LAYER_DRIFT:'+rel)
            elif rel in source_sha_before:fail('LAYER_DISAPPEARED:'+rel)
            if not target.is_file():target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(content)
            source_sha_before[rel]=sha(content)
        print('M0_C6_V3_LAYER=PASS',label,'FILES=',len(entries))
    if len(source_sha_before)!=24:fail('MODULE_FILE_COUNT:'+str(len(source_sha_before)))
    modules_count=check_sha_file(kit/'guards/modules_after.sha256',src)
    if modules_count!=24:fail('RECONSTRUCTED_MODULE_COUNT')
    # The source manifest has the S6A3 compiled chunks; source modules were unavailable on server.
    # Capture existing theme violations before M0-C6 patch, then ensure no new violations after.
    (src/'resources/views').mkdir(parents=True,exist_ok=True)
    def theme_issues():
        result=subprocess.run(['node','scripts/check-theme-boundaries.mjs'],cwd=src,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,universal_newlines=True)
        if result.returncode not in (0,1):fail('THEME_CHECK_FATAL:'+result.stdout[-600:])
        return result.returncode,result.stdout.strip()
    baseline_themes=theme_issues()
    changed=[s for s in (kit/'guards/changed_paths.txt').read_text().splitlines() if s.strip()]
    if len(changed)!=15:fail('PATCH_COUNT')
    for rel in changed:
        source=kit/'patch'/rel
        if not source.is_file() or not safe_path(rel):fail('PATCH_MISSING:'+rel)
        target=src/rel
        if not target.is_file():fail('PATCH_TARGET_MISSING:'+rel)
        target.write_bytes(source.read_bytes())
    if check_sha_file(kit/'guards/patch.sha256',src)!=15:fail('PATCH_SHA')
    after_themes=theme_issues()
    if baseline_themes!=after_themes:fail('THEME_BOUNDARIES_NEW_VIOLATIONS:BEFORE='+repr(baseline_themes)+' AFTER='+repr(after_themes))
    print('THEME_CHECK=M0C6_NO_NEW_VIOLATIONS BASELINE_STATUS=',baseline_themes[0])
    if baseline_themes[0]:
        match=re.search(r'Theme boundary violations \((\d+)\):',baseline_themes[1])
        print('PREEXISTING_THEME_WARNINGS='+str(match.group(1) if match else 'UNKNOWN'))
    # Ensure minimal expected final state and unchanged bidirectional safety boundaries.
    check_sha_file(kit/'guards/modules_after.sha256',src)
    for name in active['required_modules']:
        if not (src/'resources/js/Themes/civic/Pages/Dashboard'/name).is_file():fail('MISSING_MODULE:'+name)
    (work/'ASSEMBLY_INFO.json').write_text(json.dumps({
        'source_production_manifest_sha256':active['manifest_sha256'],
        'source_production_ssr_sha256':active['ssr_sha256'],
        'source_files_verified':baseline_count,
        'reconstituted_studio_sources':modules_count,
        'm0c6_modified_sources':len(changed),
        'theme_boundary_existing_status':baseline_themes[0],
        'theme_boundary_no_new_violations':True
    },indent=2)+'\n')
    print('M0_C6_V3_ASSEMBLY=PASS SOURCE_FILES=489 STUDIO_SOURCE_FILES=24 MODIFIED_FILES=15')
if __name__=='__main__':main()
