import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const ROOT = process.argv[2];
if (!ROOT) throw new Error('SOURCE_ROOT_REQUIRED');
const read = (p) => fs.readFileSync(path.join(ROOT,p),'utf8');
const core=read('resources/js/Core/events.js');
// Exercise the pure price helpers without importing React or touching Laravel.
function fn(name) {
  const re=new RegExp(`export function ${name}\\([^]*?\\n\\}`,'m');
  const m=core.match(re);
  if(!m)throw new Error(`FUNCTION_NOT_FOUND_${name}`);
  return m[0].replace('export function','function');
}
const t=(str, params)=>str.replace(/:([a-z_]+)/g, (_, k)=>String(params?.[k]??':'+k));
const helpers=new Function('t', `${fn('priceLabel')}\n${fn('displayPrice')}\n${fn('externalAvailabilityLabel')}\nreturn {priceLabel,displayPrice,externalAvailabilityLabel};`)(t);
const euro=(c)=>({amount:c,formatted:`€${(c/100).toFixed(2)}`});
const priced={external:{source_name:'agenda'}, price:{is_free:false,min:euro(1500),max:euro(2300)},availability:'unknown'};
assert.equal(helpers.displayPrice(priced),'From €15.00');
assert.equal(helpers.displayPrice({...priced,price:{...priced.price,max:euro(1500)}}),'€15.00');
assert.equal(helpers.displayPrice({...priced,price:{is_free:true,min:null,max:null}}),'Free');
assert.equal(helpers.displayPrice({...priced,price:{is_free:false,min:null,max:null}}),'Price not provided');
assert.equal(helpers.displayPrice({price:{is_free:false,min:null,max:null}}),null);
assert.equal(helpers.externalAvailabilityLabel(priced),'Availability to confirm with the organizer');
assert.equal(helpers.externalAvailabilityLabel({...priced,availability:'sold_out'}),'Sold out');
assert.equal(helpers.externalAvailabilityLabel({availability:'sold_out'}),null);
let assertions=8;
for (const lang of ['fr','nl']) {
 const dict=JSON.parse(read(`resources/lang/${lang}.json`));
 for (const key of ['Price not provided','Availability to confirm with the organizer','Prices and availability are provided by the official source and may change.']) {
  assert.ok(typeof dict[key]==='string' && dict[key].length>5, `${lang} ${key}`);assertions++;
 }
}
for (const theme of ['civic','almanac','marquee']) {
 const detail=read(`resources/js/Themes/${theme}/Pages/Site/Event.jsx`);
 const cards=read(`resources/js/Themes/${theme}/components/events.jsx`);
 const map=read(`resources/js/Themes/${theme}/components/MapView.jsx`);
 assert.ok(detail.includes('ExternalClaimInline'),`${theme} claim preserved`);
 assert.ok(detail.includes('Tickets and registration are managed by the organizer, not Booketik.'),`${theme} external boundary`);
 assert.ok(detail.includes('displayPrice(event)'),`${theme} detailed price`);
 assert.ok(detail.includes('externalAvailabilityLabel(event)'),`${theme} availability`);
 assert.ok(cards.includes('external={Boolean(event.external)}'),`${theme} cards external`);
 assert.ok(cards.includes("event.availability === 'sold_out'"),`${theme} card sold-out`);
 assert.ok(cards.includes('displayPrice(event)'),`${theme} mini sheet`);
 assert.ok(map.includes("(e.external ? '?' : '')"),`${theme} unknown price map`);
 assertions+=8;
}
console.log(`M0_C6_UI_SELFTEST=PASS ASSERTIONS=${assertions} EXTERNAL_CHECKOUT_UNCHANGED=YES FR_NL=PASS`);
