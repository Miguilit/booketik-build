#!/usr/bin/env bash
set -euo pipefail
KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
OUT="$(cd "${1:-$PWD}" && pwd -P)"
MODE="${2:-build}"
if [[ "$MODE" != build && "$MODE" != preflight ]]; then
  echo 'USAGE: bash m0c6v3/scripts/build.sh OUTPUT_DIRECTORY [preflight|build]' >&2
  exit 2
fi
node -e 'const v=process.versions.node.split(".").map(Number);if(v[0]!==22 || v[1]<12)process.exit(1)'
python3 -V
WORK="$(mktemp -d)"
trap 'rm -rf -- "$WORK"' EXIT
python3 "$KIT/scripts/assemble.py" "$KIT" "$WORK/merged"
SRC="$WORK/merged/source"
node "$KIT/scripts/test-ui.mjs" "$SRC"
if [[ "$MODE" == preflight ]]; then
 echo 'M0_C6_V3_PREFLIGHT=PASS BUILD_NOT_RUN=YES';exit 0
fi
cd "$SRC"
echo '===== NPM CI (GitHub Node 22) ====='
npm ci --no-audit --no-fund
echo '===== VITE CLIENT AND SSR ====='
npm run build
[[ -f public/build/manifest.json && -f bootstrap/ssr/ssr.js && -f bootstrap/ssr/ssr-manifest.json ]]
node - <<'JS'
const fs=require('fs');
const m=JSON.parse(fs.readFileSync('public/build/manifest.json','utf8'));
const s=JSON.parse(fs.readFileSync('bootstrap/ssr/ssr-manifest.json','utf8'));
for(const [label,obj] of [['CLIENT',m],['SSR',s]]) {
 for(const page of ['BooketikStudios.jsx','BooketikStudiosStandalone.jsx','BooketikVenueManager.jsx']) {
   if(!Object.keys(obj).some(k=>k.endsWith('/'+page)))throw Error('M0_C6_V3_'+label+'_MISSING_'+page);
 }
}
for(const lang of ['fr','nl','en']) {
 if(!Object.keys(m).some(k=>k.includes('lang/'+lang+'.json')))throw Error('M0_C6_V3_MISSING_LANG_'+lang);
}
if(Object.keys(m).length<226)throw Error('M0_C6_V3_CLIENT_MANIFEST_SHRUNK:'+Object.keys(m).length);
console.log('M0_C6_V3_MANIFEST=PASS CLIENT_ENTRIES='+Object.keys(m).length+' SSR_ENTRIES='+Object.keys(s).length);
JS
echo '===== GUARDED RELEASE ====='
REL="$WORK/release"
mkdir -p "$REL/assets/public" "$REL/assets/bootstrap" "$REL/sources"
cp -a "$SRC/public/build" "$REL/assets/public/build"
cp -a "$SRC/bootstrap/ssr" "$REL/assets/bootstrap/ssr"
{ cat "$KIT/guards/changed_paths.txt"; sed -E 's/^[0-9a-f]{64}  //' "$KIT/guards/modules_after.sha256"; } | LC_ALL=C sort -u > "$REL/source_deploy_paths.txt"
while IFS= read -r file; do
  [[ -z "$file" ]] && continue
  mkdir -p "$REL/sources/$(dirname "$file")"
  cp "$SRC/$file" "$REL/sources/$file"
done < "$REL/source_deploy_paths.txt"
cp "$KIT/guards/current.sha256" "$REL/source_before.sha256"
cp "$KIT/guards/modules_after.sha256" "$REL/source_added.sha256"
cp "$KIT/guards/patch.sha256" "$REL/source_modified.sha256"
cp "$WORK/merged/ASSEMBLY_INFO.json" "$REL/ASSEMBLY_INFO.json"
printf 'BUILD=BOOKETIK_M0_C6_V3_MERGED\nNODE=%s\n' "$(node -v)" > "$REL/BUILD_INFO.txt"
( cd "$REL" && find assets sources -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > release.sha256 && sha256sum -c release.sha256 >/dev/null )
NAME=BOOKETIK_M0_C6_V3_MERGED_COMPILED_20261112.tar.gz
( cd "$WORK" && tar -czf "$OUT/$NAME" release )
( cd "$OUT" && sha256sum "$NAME" > "$NAME.sha256" )
echo 'M0_C6_V3_BUILD=PASS MERGED_STUDIO=YES PRICES_UI=YES SSR=YES'
echo "RELEASE=$OUT/$NAME"
