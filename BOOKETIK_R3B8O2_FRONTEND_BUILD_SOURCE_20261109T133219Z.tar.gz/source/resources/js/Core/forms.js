/** Static content pages (Contents/Index): sanitised body, title, contact-panel decision, contact form. */
export {
    CONTACT_FIELDS,
    CONTACT_SLUGS,
    isContactPage,
    useContactForm,
    useContentPage,
} from './lib/contents';
