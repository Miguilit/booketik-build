/** Page context: locale, locale-prefixed URLs, the signed-in viewer, the site's brand. */
export { useLocale, useRoute, useViewer, useSiteBrand } from './lib/useSite';
