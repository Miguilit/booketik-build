/** Bridge tokens (`--t-*`) for colours that cannot be classes. */
export { cssColor, resolvedColor, resolvedValue, toastStyle } from './lib/bridge';
