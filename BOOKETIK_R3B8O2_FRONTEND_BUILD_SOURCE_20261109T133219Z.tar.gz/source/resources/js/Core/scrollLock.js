/** Counted page scroll lock for overlays. */
export { lockScroll } from './lib/scrollLock';
