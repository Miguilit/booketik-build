/** Formatting: `cn`, counts, money and prices, durations, initials. */
export * from './lib/format';
