/**
 * Local-channel checkout: `useOrderPolling` (an order until it settles or expires),
 * `useCheckoutDialog` (a ChargeIntent's live/settled/dead state), `intentPanel`,
 * `useCopyValue`, `useCountdown`/`msLeft`, channel labels (`describeChannel`,
 * `channelOptions`, `CHANNEL_LABELS`) and the currency switch (`useCurrencyPicker`,
 * `switchCurrency`).
 */
export * from './lib/checkout';
